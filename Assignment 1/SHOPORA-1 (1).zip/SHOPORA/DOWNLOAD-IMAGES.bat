@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "download-images.ps1"
pause
