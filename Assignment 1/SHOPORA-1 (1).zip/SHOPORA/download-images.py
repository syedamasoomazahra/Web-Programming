#!/usr/bin/env python3
"""
SHOPORA - download-images.py
Downloads the real product photographs (free to use, Pexels licence) into
assets/images/. Run once:   python download-images.py
Needs only Python 3 and an internet connection.
"""
import os, sys, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "assets", "images")

# (file name, Pexels photo id, width in pixels)
IMAGES = [
    ("p01-headphones", 3945667, 900),
    ("p02-smartwatch", 5081914, 900),
    ("p03-laptop", 11833896, 900),
    ("p04-speaker", 4917455, 900),
    ("p05-tshirt", 37704845, 900),
    ("p06-denim-jacket", 16390585, 900),
    ("p07-hoodie", 9594679, 900),
    ("p08-linen-shirt", 8483487, 900),
    ("p09-running-shoes", 260044, 900),
    ("p10-sneakers", 13560373, 900),
    ("p11-boots", 37827331, 900),
    ("p12-loafers", 27204303, 900),
    ("p13-wallet", 4452393, 900),
    ("p14-sunglasses", 5202048, 900),
    ("p15-belt", 31959216, 900),
    ("p16-wristwatch", 380782, 900),
    ("p17-handbag", 7953286, 900),
    ("p18-tote", 9327162, 900),
    ("p19-carry-bag", 27046143, 900),
    ("p20-necklace", 4735885, 900),
    ("p21-rings", 17261921, 900),
    ("p22-earrings", 5370644, 900),
    ("p23-bracelet", 37401994, 900),
    ("p24-kettle", 10965749, 900),
    ("p25-blender", 8845109, 900),
    ("p26-fan", 8102643, 900),
    ("p27-coffee-maker", 12122684, 900),
    ("cat-electronics", 3945667, 900),
    ("cat-clothing", 8483487, 900),
    ("cat-shoes", 37827331, 900),
    ("cat-accessories", 5202048, 900),
    ("cat-handbags", 7953286, 900),
    ("cat-jewelry", 4735885, 900),
    ("cat-appliances", 10965749, 900),
    ("hero-1", 914930, 1800),
    ("hero-2", 6567204, 1800),
    ("hero-3", 9327162, 1800),
    ("about", 8483478, 1800),
    ("auth", 4857762, 1800)
]

# images replaced in this update: always downloaded again
FORCE = {"p07-hoodie", "hero-1"}

URL = "https://images.pexels.com/photos/{id}/pexels-photo-{id}.jpeg?auto=compress&cs=tinysrgb&w={w}"

def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (SHOPORA image downloader)"})
    with urllib.request.urlopen(req, timeout=40) as r:
        return r.read()

def main():
    os.makedirs(OUT, exist_ok=True)
    failed = []
    for name, pid, width in IMAGES:
        path = os.path.join(OUT, name + ".jpg")
        if name not in FORCE and os.path.exists(path) and os.path.getsize(path) > 5000:
            print("skip  ", name); continue
        for attempt in range(3):
            try:
                data = fetch(URL.format(id=pid, w=width))
                if len(data) < 5000: raise ValueError("file too small")
                with open(path, "wb") as f: f.write(data)
                print("ok    ", name, "(%d KB)" % (len(data) // 1024)); break
            except Exception as e:
                if attempt == 2: print("FAILED", name, e); failed.append(name)
                else: time.sleep(1.5)
    print("\nDone. %d of %d images present." % (len(IMAGES) - len(failed), len(IMAGES)))
    if failed: print("Failed:", ", ".join(failed)); sys.exit(1)

if __name__ == "__main__":
    main()
