# SHOPORA - download-images.ps1  (Windows PowerShell)
# Downloads the real product photographs (Pexels licence) into assets\images
$ErrorActionPreference = "Continue"
$out = Join-Path $PSScriptRoot "assets\images"
New-Item -ItemType Directory -Force -Path $out | Out-Null
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$images = @(
  @("p01-headphones", 3945667, 900)
  ,@("p02-smartwatch", 5081914, 900)
  ,@("p03-laptop", 11833896, 900)
  ,@("p04-speaker", 4917455, 900)
  ,@("p05-tshirt", 37704845, 900)
  ,@("p06-denim-jacket", 16390585, 900)
  ,@("p07-hoodie", 9594679, 900)
  ,@("p08-linen-shirt", 8483487, 900)
  ,@("p09-running-shoes", 260044, 900)
  ,@("p10-sneakers", 13560373, 900)
  ,@("p11-boots", 37827331, 900)
  ,@("p12-loafers", 27204303, 900)
  ,@("p13-wallet", 4452393, 900)
  ,@("p14-sunglasses", 5202048, 900)
  ,@("p15-belt", 31959216, 900)
  ,@("p16-wristwatch", 380782, 900)
  ,@("p17-handbag", 7953286, 900)
  ,@("p18-tote", 9327162, 900)
  ,@("p19-carry-bag", 27046143, 900)
  ,@("p20-necklace", 4735885, 900)
  ,@("p21-rings", 17261921, 900)
  ,@("p22-earrings", 5370644, 900)
  ,@("p23-bracelet", 37401994, 900)
  ,@("p24-kettle", 10965749, 900)
  ,@("p25-blender", 8845109, 900)
  ,@("p26-fan", 8102643, 900)
  ,@("p27-coffee-maker", 12122684, 900)
  ,@("cat-electronics", 3945667, 900)
  ,@("cat-clothing", 8483487, 900)
  ,@("cat-shoes", 37827331, 900)
  ,@("cat-accessories", 5202048, 900)
  ,@("cat-handbags", 7953286, 900)
  ,@("cat-jewelry", 4735885, 900)
  ,@("cat-appliances", 10965749, 900)
  ,@("hero-1", 914930, 1800)
  ,@("hero-2", 6567204, 1800)
  ,@("hero-3", 9327162, 1800)
  ,@("about", 8483478, 1800)
  ,@("auth", 4857762, 1800)
)
$force = @("p07-hoodie", "hero-1")
$failed = @()
foreach ($i in $images) {
  $file = Join-Path $out ($i[0] + ".jpg")
  if (($force -notcontains $i[0]) -and (Test-Path $file) -and ((Get-Item $file).Length -gt 5000)) { Write-Host "skip   $($i[0])"; continue }
  $url = "https://images.pexels.com/photos/$($i[1])/pexels-photo-$($i[1]).jpeg?auto=compress&cs=tinysrgb&w=$($i[2])"
  try { Invoke-WebRequest -Uri $url -OutFile $file -UserAgent "Mozilla/5.0" -UseBasicParsing; Write-Host "ok     $($i[0])" }
  catch { Write-Host "FAILED $($i[0])"; $failed += $i[0] }
}
Write-Host ""
Write-Host "Done. $($images.Count - $failed.Count) of $($images.Count) images present."
