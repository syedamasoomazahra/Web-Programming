/* =====================================================================
   SHOPORA - data.js
   Product catalogue, categories and slideshow content.
   Edit this file to add or change products. Image files live in
   assets/images/ (see download-images.py / README.txt).
   ===================================================================== */

/* Pexels photo ids for every local image. If assets/images/<name>.jpg is missing,
   app.js loads the same photo from the Pexels CDN instead (needs internet). */
const REMOTE_IMAGES = {
  "p01-headphones": [3945667, 900],
  "p02-smartwatch": [5081914, 900],
  "p03-laptop": [11833896, 900],
  "p04-speaker": [4917455, 900],
  "p05-tshirt": [37704845, 900],
  "p06-denim-jacket": [16390585, 900],
  "p07-hoodie": [9594679, 900],
  "p08-linen-shirt": [8483487, 900],
  "p09-running-shoes": [260044, 900],
  "p10-sneakers": [13560373, 900],
  "p11-boots": [37827331, 900],
  "p12-loafers": [27204303, 900],
  "p13-wallet": [4452393, 900],
  "p14-sunglasses": [5202048, 900],
  "p15-belt": [31959216, 900],
  "p16-wristwatch": [380782, 900],
  "p17-handbag": [7953286, 900],
  "p18-tote": [9327162, 900],
  "p19-carry-bag": [27046143, 900],
  "p20-necklace": [4735885, 900],
  "p21-rings": [17261921, 900],
  "p22-earrings": [5370644, 900],
  "p23-bracelet": [37401994, 900],
  "p24-kettle": [10965749, 900],
  "p25-blender": [8845109, 900],
  "p26-fan": [8102643, 900],
  "p27-coffee-maker": [12122684, 900],
  "cat-electronics": [3945667, 900],
  "cat-clothing": [8483487, 900],
  "cat-shoes": [37827331, 900],
  "cat-accessories": [5202048, 900],
  "cat-handbags": [7953286, 900],
  "cat-jewelry": [4735885, 900],
  "cat-appliances": [10965749, 900],
  "hero-1": [914930, 1800],
  "hero-2": [6567204, 1800],
  "hero-3": [9327162, 1800],
  "about": [8483478, 1800],
  "auth": [4857762, 1800]
};

const CURRENCY = "Rs. ";

const CATEGORIES = [
  { name: "Electronics",     image: "assets/images/cat-electronics.jpg", text: "Headphones, watches, laptops" },
  { name: "Clothing",        image: "assets/images/cat-clothing.jpg",    text: "Tees, denim, knitwear" },
  { name: "Shoes",           image: "assets/images/cat-shoes.jpg",       text: "Running, sneakers, boots" },
  { name: "Accessories",     image: "assets/images/cat-accessories.jpg", text: "Wallets, belts, eyewear" },
  { name: "Handbags",        image: "assets/images/cat-handbags.jpg",    text: "Leather totes and carry-alls" },
  { name: "Jewelry",         image: "assets/images/cat-jewelry.jpg",     text: "Necklaces, rings, earrings" },
  { name: "Home Appliances", image: "assets/images/cat-appliances.jpg",  text: "Kettles, blenders, fans" }
];

/* tags: "featured" | "new" | "best" | "offer" (used by the home page sections) */
const PRODUCTS = [
  // ---- Electronics ----
  { id: 1,  name: "Studio Wireless Headphones", category: "Electronics", brand: "Nova", price: 12999, oldPrice: 0,     rating: 4.6, reviews: 214, image: "assets/images/p01-headphones.jpg", tags: ["featured", "best"],
    description: "Over-ear wireless headphones with deep bass, active noise reduction and up to 30 hours of battery life. Soft memory-foam cushions keep them comfortable all day." },
  { id: 2,  name: "Pulse Smart Watch", category: "Electronics", brand: "Nova", price: 18999, oldPrice: 22999, rating: 4.3, reviews: 158, image: "assets/images/p02-smartwatch.jpg", tags: ["new", "offer"],
    description: "Track steps, heart rate and sleep, and get phone notifications on your wrist. Water resistant with a bright always-on display." },
  { id: 3,  name: "Aero 15 Laptop", category: "Electronics", brand: "Zenith", price: 189999, oldPrice: 0, rating: 4.5, reviews: 96, image: "assets/images/p03-laptop.jpg", tags: ["featured"],
    description: "A slim 15-inch laptop with 16GB RAM and a 512GB SSD. Fast enough for study, office work and programming, light enough to carry daily." },
  { id: 4,  name: "Echo Portable Speaker", category: "Electronics", brand: "Zenith", price: 8499, oldPrice: 10999, rating: 4.1, reviews: 77, image: "assets/images/p04-speaker.jpg", tags: ["offer"],
    description: "Compact Bluetooth speaker with clear sound and strong bass. Pairs with any phone and plays for 12 hours on one charge." },

  // ---- Clothing ----
  { id: 5,  name: "Essential Cotton Tee", category: "Clothing", brand: "Urban", price: 2499, oldPrice: 0, rating: 4.4, reviews: 342, image: "assets/images/p05-tshirt.jpg", tags: ["best"],
    description: "Soft 100% combed-cotton t-shirt with a relaxed regular fit. Easy to wash and comfortable to wear all day." },
  { id: 6,  name: "Heritage Denim Jacket", category: "Clothing", brand: "Urban", price: 9999, oldPrice: 12499, rating: 4.5, reviews: 121, image: "assets/images/p06-denim-jacket.jpg", tags: ["new", "offer"],
    description: "Classic mid-blue denim jacket with a button front and two chest pockets. A reliable layer for cool evenings." },
  { id: 7,  name: "Cloud Fleece Hoodie", category: "Clothing", brand: "Luxe", price: 6499, oldPrice: 0, rating: 4.2, reviews: 189, image: "assets/images/p07-hoodie.jpg", tags: ["featured", "new"],
    description: "Brushed-fleece hoodie with a roomy hood and kangaroo pocket. Warm, soft and built for everyday wear." },
  { id: 8,  name: "Coastal Linen Shirt", category: "Clothing", brand: "Luxe", price: 5499, oldPrice: 0, rating: 4.0, reviews: 64, image: "assets/images/p08-linen-shirt.jpg", tags: ["new"],
    description: "Breathable linen-blend shirt in a relaxed cut. Light enough for summer, smart enough for dinner." },

  // ---- Shoes ----
  { id: 9,  name: "Stride Running Shoes", category: "Shoes", brand: "Stride", price: 11999, oldPrice: 14999, rating: 4.4, reviews: 233, image: "assets/images/p09-running-shoes.jpg", tags: ["best", "offer"],
    description: "Lightweight running shoes with a cushioned sole and breathable mesh upper. Good grip on road and track." },
  { id: 10, name: "Court White Sneakers", category: "Shoes", brand: "Stride", price: 8999, oldPrice: 0, rating: 4.3, reviews: 176, image: "assets/images/p10-sneakers.jpg", tags: ["featured"],
    description: "Clean white leather-look sneakers that go with almost everything. Padded insole for all-day comfort." },
  { id: 11, name: "Ridge Leather Boots", category: "Shoes", brand: "Luxe", price: 16999, oldPrice: 0, rating: 4.7, reviews: 88, image: "assets/images/p11-boots.jpg", tags: ["featured", "new"],
    description: "Hard-wearing leather boots with a stitched sole and ankle support. They get better with age." },
  { id: 12, name: "Oxford Leather Loafers", category: "Shoes", brand: "Luxe", price: 13499, oldPrice: 0, rating: 4.1, reviews: 52, image: "assets/images/p12-loafers.jpg", tags: [],
    description: "Slip-on leather loafers with a polished finish. Dress them up for work or down for the weekend." },

  // ---- Accessories ----
  { id: 13, name: "Heritage Leather Wallet", category: "Accessories", brand: "Luxe", price: 3999, oldPrice: 0, rating: 4.5, reviews: 301, image: "assets/images/p13-wallet.jpg", tags: ["best"],
    description: "Slim genuine-leather wallet with card slots, a note compartment and a coin pocket." },
  { id: 14, name: "Solace Sunglasses", category: "Accessories", brand: "Urban", price: 4499, oldPrice: 5999, rating: 4.0, reviews: 109, image: "assets/images/p14-sunglasses.jpg", tags: ["offer"],
    description: "UV400 protection lenses in a lightweight black frame. Comes with a hard case and cleaning cloth." },
  { id: 15, name: "Classic Leather Belt", category: "Accessories", brand: "Luxe", price: 2999, oldPrice: 0, rating: 4.2, reviews: 95, image: "assets/images/p15-belt.jpg", tags: [],
    description: "Full-grain leather belt with a brushed metal buckle. Goes with jeans and formal trousers alike." },
  { id: 16, name: "Meridian Wrist Watch", category: "Accessories", brand: "Nova", price: 15999, oldPrice: 0, rating: 4.6, reviews: 143, image: "assets/images/p16-wristwatch.jpg", tags: ["featured"],
    description: "A timeless analogue watch with a stainless-steel case and scratch-resistant glass." },

  // ---- Handbags ----
  { id: 17, name: "Maison Leather Handbag", category: "Handbags", brand: "Luxe", price: 21999, oldPrice: 26999, rating: 4.7, reviews: 87, image: "assets/images/p17-handbag.jpg", tags: ["featured", "offer"],
    description: "Structured leather handbag with a roomy interior, inner zip pocket and a detachable shoulder strap." },
  { id: 18, name: "Atelier Everyday Tote", category: "Handbags", brand: "Urban", price: 12999, oldPrice: 0, rating: 4.4, reviews: 132, image: "assets/images/p18-tote.jpg", tags: ["best"],
    description: "A spacious everyday tote that fits a laptop, a book and your lunch. Reinforced handles and a magnetic closure." },
  { id: 19, name: "Voyage Carry Bag", category: "Handbags", brand: "Urban", price: 14999, oldPrice: 0, rating: 4.3, reviews: 61, image: "assets/images/p19-carry-bag.jpg", tags: ["new"],
    description: "Soft-structured carry bag in warm neutral tones with multiple compartments for daily essentials." },

  // ---- Jewelry ----
  { id: 20, name: "Aurelia Pendant Necklace", category: "Jewelry", brand: "Aurum", price: 7999, oldPrice: 9999, rating: 4.6, reviews: 174, image: "assets/images/p20-necklace.jpg", tags: ["featured", "offer"],
    description: "A delicate gold-tone pendant necklace on a fine chain. Hypoallergenic and tarnish resistant." },
  { id: 21, name: "Lumiere Ring Set", category: "Jewelry", brand: "Aurum", price: 5999, oldPrice: 0, rating: 4.3, reviews: 118, image: "assets/images/p21-rings.jpg", tags: ["new"],
    description: "A set of stackable rings you can wear together or apart. Smooth finish and a comfortable band." },
  { id: 22, name: "Stella Stud Earrings", category: "Jewelry", brand: "Aurum", price: 4499, oldPrice: 0, rating: 4.5, reviews: 205, image: "assets/images/p22-earrings.jpg", tags: ["best"],
    description: "Sparkling stud earrings with a secure butterfly back. Small enough for every day, bright enough for occasions." },
  { id: 23, name: "Soleil Charm Bracelet", category: "Jewelry", brand: "Aurum", price: 6499, oldPrice: 0, rating: 4.2, reviews: 73, image: "assets/images/p23-bracelet.jpg", tags: [],
    description: "A fine chain bracelet with an adjustable clasp. Layers beautifully with other pieces." },

  // ---- Home Appliances ----
  { id: 24, name: "Hearth Electric Kettle", category: "Home Appliances", brand: "Homely", price: 5499, oldPrice: 6999, rating: 4.3, reviews: 251, image: "assets/images/p24-kettle.jpg", tags: ["offer", "best"],
    description: "1.7 litre glass electric kettle with auto shut-off and boil-dry protection. Boils in about three minutes." },
  { id: 25, name: "Fresh Juice Blender", category: "Home Appliances", brand: "Homely", price: 9999, oldPrice: 0, rating: 4.1, reviews: 90, image: "assets/images/p25-blender.jpg", tags: ["new"],
    description: "Powerful 600W blender with a 1.5 litre jar. Smoothies, soups and sauces in seconds." },
  { id: 26, name: "Breeze Desk Fan", category: "Home Appliances", brand: "Homely", price: 6999, oldPrice: 8499, rating: 4.0, reviews: 66, image: "assets/images/p26-fan.jpg", tags: ["offer"],
    description: "Quiet desk fan with three speed settings and an adjustable head. Saves electricity." },
  { id: 27, name: "Moka Coffee Maker", category: "Home Appliances", brand: "Homely", price: 4999, oldPrice: 0, rating: 4.6, reviews: 187, image: "assets/images/p27-coffee-maker.jpg", tags: ["featured"],
    description: "Stovetop moka pot that brews rich, espresso-style coffee. Durable aluminium body, easy to clean." }
];

const BRANDS = Array.from(new Set(PRODUCTS.map(function (p) { return p.brand; }))).sort();

/* Homepage slideshow (images are wide lifestyle photos). */
const SLIDES = [
  { image: "assets/images/hero-1.jpg", eyebrow: "New season",        title: "Dressed for every day",     text: "Considered essentials in warm, natural tones.",  link: "products.html?category=Clothing",   cta: "Shop Clothing" },
  { image: "assets/images/hero-2.jpg", eyebrow: "Limited offers",    title: "Up to 25% off selected",    text: "Hand-picked pieces at special prices this month.", link: "products.html?tag=offer",          cta: "View Offers" },
  { image: "assets/images/hero-3.jpg", eyebrow: "Everyday luxury",   title: "Bags, jewelry & more",      text: "Finishing touches that make an outfit.",           link: "products.html?category=Handbags",  cta: "Shop Handbags" }
];
