/* =====================================================================
   SHOPORA - auth.js  (login.html)
   Login / Signup validation (front-end demo, no server) and the
   account area (profile, orders, settings) shown after login.

   NOTE: a real website would verify passwords on a server. Here users
   are saved in Local Storage only to demonstrate form handling.
   ===================================================================== */

(function () {
  const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  /* ---------- Validation helpers ---------- */
  function setError(inputId, message) {
    const input = document.getElementById(inputId);
    const error = document.getElementById(inputId + "Error");
    error.textContent = message;
    input.classList.toggle("invalid", Boolean(message));
    input.setAttribute("aria-invalid", Boolean(message));
    return !message;
  }

  function checkName(id) {
    const v = document.getElementById(id).value.trim();
    if (v.length < 3) { return setError(id, "Name must be at least 3 characters."); }
    if (!/^[A-Za-z][A-Za-z\s.'-]*$/.test(v)) { return setError(id, "Name can contain letters and spaces only."); }
    return setError(id, "");
  }

  function checkEmail(id) {
    const v = document.getElementById(id).value.trim();
    if (!v) { return setError(id, "Email is required."); }
    if (!EMAIL_PATTERN.test(v)) { return setError(id, "Enter a valid email, e.g. name@example.com."); }
    return setError(id, "");
  }

  function checkPassword(id, strict) {
    const v = document.getElementById(id).value;
    if (!v) { return setError(id, "Password is required."); }
    if (v.length < 6) { return setError(id, "Password must be at least 6 characters."); }
    if (strict && !(/[A-Za-z]/.test(v) && /\d/.test(v))) { return setError(id, "Use both letters and numbers."); }
    return setError(id, "");
  }

  function checkConfirm() {
    const pass = document.getElementById("signupPassword").value;
    const confirm = document.getElementById("signupConfirm").value;
    if (!confirm) { return setError("signupConfirm", "Please confirm your password."); }
    if (pass !== confirm) { return setError("signupConfirm", "Passwords do not match."); }
    return setError("signupConfirm", "");
  }

  /* A tiny non-secure hash so the demo does not keep plain passwords. */
  function hash(text) {
    let h = 0;
    for (let i = 0; i < text.length; i++) { h = (h * 31 + text.charCodeAt(i)) | 0; }
    return String(h);
  }

  /* ---------- Tabs: login / signup ---------- */
  function showTab(tab) {
    const login = tab === "login";
    document.getElementById("loginForm").hidden = !login;
    document.getElementById("signupForm").hidden = login;
    document.getElementById("loginTab").classList.toggle("active", login);
    document.getElementById("signupTab").classList.toggle("active", !login);
    document.getElementById("authTitle").textContent = login ? "Welcome back" : "Create your account";
    document.getElementById("authSub").textContent = login
      ? "Log in to view your orders and checkout faster."
      : "Join SHOPORA to save your wishlist and track orders.";
  }

  /* ---------- Submit handlers ---------- */
  function onLogin(event) {
    event.preventDefault();
    const okEmail = checkEmail("loginEmail");
    const okPass = checkPassword("loginPassword", false);
    if (!okEmail || !okPass) { return; }

    const email = document.getElementById("loginEmail").value.trim().toLowerCase();
    const pass = document.getElementById("loginPassword").value;
    const user = Store.getUsers().find(function (u) { return u.email === email; });

    if (!user) { return setError("loginEmail", "No account found with this email. Please sign up first."); }
    if (user.pass !== hash(pass)) { return setError("loginPassword", "Incorrect password."); }
    finishLogin(user);
  }

  function onSignup(event) {
    event.preventDefault();
    const results = [checkName("signupName"), checkEmail("signupEmail"), checkPassword("signupPassword", true), checkConfirm()];
    if (results.indexOf(false) !== -1) { return; }

    const name = document.getElementById("signupName").value.trim();
    const email = document.getElementById("signupEmail").value.trim().toLowerCase();
    const users = Store.getUsers();
    if (users.some(function (u) { return u.email === email; })) {
      return setError("signupEmail", "This email is already registered. Please log in.");
    }
    const user = { name: name, email: email, pass: hash(document.getElementById("signupPassword").value) };
    users.push(user);
    Store.saveUsers(users);
    finishLogin(user);
  }

  function finishLogin(user) {
    Store.setUser({ name: user.name, email: user.email });
    Shopora.toast("Welcome, " + user.name.split(" ")[0] + "!");
    const next = Shopora.getParam("next");
    setTimeout(function () {
      if (next === "cart") { window.location.href = "cart.html"; }
      else { window.location.hash = "#profile"; window.location.reload(); }
    }, 700);
  }

  /* ---------- Account area (after login) ---------- */
  function showAccount(section) {
    document.getElementById("authCard").hidden = true;
    document.getElementById("accountArea").hidden = false;
    const name = ["profile", "orders", "settings"].indexOf(section) !== -1 ? section : "profile";
    document.querySelectorAll(".account-tab").forEach(function (b) { b.classList.toggle("active", b.dataset.section === name); });
    document.querySelectorAll(".account-panel").forEach(function (p) { p.hidden = p.id !== "panel-" + name; });
    if (name === "profile") { renderProfile(); }
    if (name === "orders") { renderOrders(); }
  }

  function renderProfile() {
    const user = Store.getUser();
    document.getElementById("profileBox").innerHTML =
      '<div class="avatar">' + Shopora.escape(user.name.charAt(0).toUpperCase()) + "</div>" +
      "<h3>" + Shopora.escape(user.name) + "</h3><p>" + Shopora.escape(user.email) + "</p>" +
      '<dl class="profile-stats"><div><dt>Cart items</dt><dd>' + Store.cartCount() + "</dd></div>" +
      "<div><dt>Wishlist</dt><dd>" + Store.getWishlist().length + "</dd></div>" +
      "<div><dt>Orders</dt><dd>" + Store.getOrders().length + "</dd></div></dl>";
  }

  function renderOrders() {
    const orders = Store.getOrders();
    const box = document.getElementById("ordersBox");
    if (orders.length === 0) {
      box.innerHTML = '<div class="empty-state"><p>You have not placed any orders yet.</p><a class="btn btn-primary" href="products.html">Start shopping</a></div>';
      return;
    }
    box.innerHTML = orders.map(function (o) {
      return '<article class="order-card"><header><strong>Order ' + o.id + "</strong><span>" + o.date + "</span></header><ul>" +
        o.items.map(function (i) { return "<li><span>" + Shopora.escape(i.name) + " × " + i.qty + "</span><span>" + Shopora.formatPrice(i.price * i.qty) + "</span></li>"; }).join("") +
        '</ul><footer><span class="status">Processing (demo)</span><strong>Total ' + Shopora.formatPrice(o.total) + "</strong></footer></article>";
    }).join("");
  }

  function bindAccountEvents() {
    document.querySelectorAll(".account-tab").forEach(function (b) {
      b.addEventListener("click", function () {
        history.replaceState(null, "", "#" + b.dataset.section);
        showAccount(b.dataset.section);
      });
    });
    document.getElementById("accLogout").addEventListener("click", function () {
      Store.logout(); Shopora.toast("You have been logged out");
      setTimeout(function () { window.location.href = "login.html"; }, 600);
    });
    document.getElementById("clearWishlistBtn").addEventListener("click", function () {
      Store.getWishlist().slice().forEach(Store.removeFromWishlist); Shopora.updateCounts(); Shopora.toast("Wishlist cleared");
    });
    document.getElementById("clearCartBtn").addEventListener("click", function () {
      Store.clearCart(); Shopora.updateCounts(); Shopora.toast("Cart cleared");
    });
    document.getElementById("clearOrdersBtn").addEventListener("click", function () {
      Store.saveOrders([]); Shopora.toast("Order history cleared");
    });
  }

  /* ---------- Start ---------- */
  document.addEventListener("DOMContentLoaded", function () {
    const hash = window.location.hash.replace("#", "");

    if (Store.getUser()) {
      bindAccountEvents();
      showAccount(hash);
      window.addEventListener("hashchange", function () { showAccount(window.location.hash.replace("#", "")); });
      return;
    }

    // not logged in: show the login / signup card
    document.getElementById("accountArea").hidden = true;
    showTab(hash === "signup" ? "signup" : "login");
    document.getElementById("loginTab").addEventListener("click", function () { showTab("login"); });
    document.getElementById("signupTab").addEventListener("click", function () { showTab("signup"); });
    document.getElementById("toSignup").addEventListener("click", function () { showTab("signup"); });
    document.getElementById("toLogin").addEventListener("click", function () { showTab("login"); });
    document.getElementById("loginForm").addEventListener("submit", onLogin);
    document.getElementById("signupForm").addEventListener("submit", onSignup);

    // live validation when leaving a field
    [["loginEmail", checkEmail], ["signupName", checkName], ["signupEmail", checkEmail]].forEach(function (pair) {
      document.getElementById(pair[0]).addEventListener("blur", function () { pair[1](pair[0]); });
    });
    document.getElementById("loginPassword").addEventListener("blur", function () { checkPassword("loginPassword", false); });
    document.getElementById("signupPassword").addEventListener("blur", function () { checkPassword("signupPassword", true); });
    document.getElementById("signupConfirm").addEventListener("blur", checkConfirm);

    // show / hide password buttons
    document.querySelectorAll(".toggle-pass").forEach(function (btn) {
      btn.addEventListener("click", function () {
        const input = document.getElementById(btn.dataset.target);
        const show = input.type === "password";
        input.type = show ? "text" : "password";
        btn.textContent = show ? "Hide" : "Show";
      });
    });
  });
})();
