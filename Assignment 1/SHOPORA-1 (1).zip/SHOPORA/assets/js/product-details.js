/* =====================================================================
   SHOPORA - product-details.js  (product.html?id=N)
   Shows one product: large image, price, description, quantity,
   add-to-cart, wishlist, and related products.
   ===================================================================== */

(function () {
  let qty = 1;
  let product = null;

  function render() {
    const box = document.getElementById("detailsBox");
    const p = product;
    const wished = Store.isWished(p.id);
    const save = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;

    document.title = p.name + " | SHOPORA";
    document.getElementById("crumbCategory").textContent = p.category;
    document.getElementById("crumbCategory").href = "products.html?category=" + encodeURIComponent(p.category);
    document.getElementById("crumbName").textContent = p.name;

    box.innerHTML =
      '<div class="details-media"><div class="zoom-frame" id="zoomFrame">' +
        '<img src="' + p.image + '" alt="' + Shopora.escape(p.name) + '" id="detailImage"></div>' +
        (save ? '<span class="tag tag-sale">-' + save + '%</span>' : "") + "</div>" +
      '<div class="details-info">' +
        '<p class="card-cat">' + p.category + " · " + p.brand + "</p>" +
        "<h1>" + Shopora.escape(p.name) + "</h1>" +
        Shopora.starsHTML(p.rating, p.reviews) +
        '<p class="price price-large"><span class="price-now">' + Shopora.formatPrice(p.price) + "</span>" +
          (p.oldPrice ? '<span class="price-old">' + Shopora.formatPrice(p.oldPrice) + "</span>" : "") + "</p>" +
        '<p class="details-desc">' + Shopora.escape(p.description) + "</p>" +
        '<ul class="details-points">' +
          "<li>" + Shopora.icon("truck") + "Free delivery on orders over " + Shopora.formatPrice(15000) + "</li>" +
          "<li>" + Shopora.icon("refresh") + "14-day easy returns</li>" +
          "<li>" + Shopora.icon("shield") + "Quality checked before dispatch</li></ul>" +
        '<div class="qty-row"><span class="field-label">Quantity</span>' +
          '<div class="qty-control"><button type="button" id="qtyMinus" aria-label="Decrease quantity">−</button>' +
          '<output id="qtyValue">1</output>' +
          '<button type="button" id="qtyPlus" aria-label="Increase quantity">+</button></div></div>' +
        '<div class="details-actions">' +
          '<button class="btn btn-primary btn-lg" id="addToCartBtn">Add to Cart</button>' +
          '<button class="btn btn-outline btn-lg" id="buyNowBtn">Buy Now</button>' +
          '<button class="wish-btn wish-inline' + (wished ? " active" : "") + '" id="detailWish" aria-label="Toggle wishlist" aria-pressed="' + wished + '">' + Shopora.icon("heart") + "</button>" +
        "</div></div>";

    bindDetailEvents();
    renderRelated();
  }

  function bindDetailEvents() {
    const qtyValue = document.getElementById("qtyValue");
    document.getElementById("qtyMinus").addEventListener("click", function () {
      qty = Math.max(1, qty - 1); qtyValue.textContent = qty;
    });
    document.getElementById("qtyPlus").addEventListener("click", function () {
      qty = Math.min(10, qty + 1); qtyValue.textContent = qty;
    });

    document.getElementById("addToCartBtn").addEventListener("click", function () {
      Store.addToCart(product.id, qty);
      Shopora.updateCounts();
      Shopora.pulse(document.getElementById("cartIcon"));
      Shopora.toast(qty + " × " + product.name + " added to cart");
    });

    document.getElementById("buyNowBtn").addEventListener("click", function () {
      Store.addToCart(product.id, qty);
      window.location.href = "cart.html";
    });

    const wishBtn = document.getElementById("detailWish");
    wishBtn.addEventListener("click", function () {
      const added = Store.toggleWishlist(product.id);
      wishBtn.classList.toggle("active", added);
      wishBtn.setAttribute("aria-pressed", added);
      Shopora.updateCounts();
      Shopora.pulse(wishBtn);
      Shopora.toast(added ? "Added to wishlist" : "Removed from wishlist");
    });

    // zoom-follow effect on the large image
    const frame = document.getElementById("zoomFrame");
    const img = document.getElementById("detailImage");
    frame.addEventListener("mousemove", function (e) {
      const r = frame.getBoundingClientRect();
      img.style.transformOrigin = ((e.clientX - r.left) / r.width * 100) + "% " + ((e.clientY - r.top) / r.height * 100) + "%";
    });
  }

  function renderRelated() {
    const related = PRODUCTS.filter(function (p) { return p.category === product.category && p.id !== product.id; });
    const fill = PRODUCTS.filter(function (p) { return p.category !== product.category && p.tags.indexOf("featured") !== -1; });
    Shopora.renderCards(related.concat(fill).slice(0, 4), "relatedGrid");
  }

  document.addEventListener("DOMContentLoaded", function () {
    product = Shopora.getProduct(Shopora.getParam("id"));
    if (!product) {
      document.getElementById("detailsBox").innerHTML =
        '<div class="empty-state"><h2>Product not found</h2><p>This product does not exist or the link is incorrect.</p>' +
        '<a class="btn btn-primary" href="products.html">Browse all products</a></div>';
      document.getElementById("relatedSection").hidden = true;
      return;
    }
    render();
  });
})();
