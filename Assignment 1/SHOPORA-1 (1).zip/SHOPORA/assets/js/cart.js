/* =====================================================================
   SHOPORA - cart.js  (cart.html)
   Shows cart items, quantity controls, remove, automatic subtotal /
   shipping / discount / total, and a demo checkout (front-end only).
   ===================================================================== */

(function () {
  const FREE_SHIPPING_OVER = 15000;
  const SHIPPING_FEE = 500;
  const COUPON_CODE = "SHOPORA10";   // demo coupon: 10% off
  const COUPON_RATE = 0.10;
  let couponApplied = false;

  /* Join cart entries with product data; drop entries whose product no longer exists. */
  function getLines() {
    return Store.getCart().map(function (item) {
      return { product: Shopora.getProduct(item.id), qty: item.qty };
    }).filter(function (line) { return line.product; });
  }

  function calculate(lines) {
    const subtotal = lines.reduce(function (sum, l) { return sum + l.product.price * l.qty; }, 0);
    const discount = couponApplied ? Math.round(subtotal * COUPON_RATE) : 0;
    const shipping = subtotal === 0 || subtotal - discount >= FREE_SHIPPING_OVER ? 0 : SHIPPING_FEE;
    return { subtotal: subtotal, discount: discount, shipping: shipping, total: subtotal - discount + shipping };
  }

  function render() {
    const content = document.getElementById("cartContent");
    const lines = getLines();
    Shopora.updateCounts();

    if (lines.length === 0) {
      content.innerHTML =
        '<div class="empty-state"><h2>Your cart is empty</h2><p>Looks like you have not added anything yet.</p>' +
        '<a class="btn btn-primary" href="products.html">Start shopping</a></div>';
      return;
    }

    const totals = calculate(lines);
    const remaining = FREE_SHIPPING_OVER - (totals.subtotal - totals.discount);

    content.innerHTML =
      '<div class="cart-layout"><div class="cart-list">' +
        lines.map(function (l) {
          const p = l.product;
          return '<article class="cart-item" data-id="' + p.id + '">' +
            '<a href="product.html?id=' + p.id + '" class="cart-thumb"><img src="' + p.image + '" alt="' + Shopora.escape(p.name) + '"></a>' +
            '<div class="cart-info"><p class="card-cat">' + p.category + '</p>' +
              '<h3><a href="product.html?id=' + p.id + '">' + Shopora.escape(p.name) + "</a></h3>" +
              '<p class="cart-unit">' + Shopora.formatPrice(p.price) + " each</p></div>" +
            '<div class="qty-control" aria-label="Quantity">' +
              '<button type="button" data-cart="minus" data-id="' + p.id + '" aria-label="Decrease quantity">−</button>' +
              "<output>" + l.qty + "</output>" +
              '<button type="button" data-cart="plus" data-id="' + p.id + '" aria-label="Increase quantity">+</button></div>' +
            '<p class="cart-line-total">' + Shopora.formatPrice(p.price * l.qty) + "</p>" +
            '<button class="icon-btn remove-btn" data-cart="remove" data-id="' + p.id + '" aria-label="Remove ' + Shopora.escape(p.name) + '">' + Shopora.icon("trash") + "</button>" +
          "</article>";
        }).join("") +
        '<div class="cart-footer-row"><a class="link-arrow" href="products.html">← Continue shopping</a>' +
        '<button class="link-btn" data-cart="clear">Clear cart</button></div></div>' +

      '<aside class="summary-card"><h2>Order Summary</h2>' +
        '<div class="free-ship">' + (remaining > 0
          ? "Add " + Shopora.formatPrice(remaining) + " more for free delivery"
          : "You have free delivery") +
          '<div class="progress"><span style="width:' + Math.min(100, ((totals.subtotal - totals.discount) / FREE_SHIPPING_OVER) * 100) + '%"></span></div></div>' +
        '<dl class="summary-rows">' +
          "<div><dt>Subtotal</dt><dd>" + Shopora.formatPrice(totals.subtotal) + "</dd></div>" +
          (couponApplied ? '<div class="discount"><dt>Discount (' + COUPON_CODE + ")</dt><dd>− " + Shopora.formatPrice(totals.discount) + "</dd></div>" : "") +
          "<div><dt>Shipping</dt><dd>" + (totals.shipping ? Shopora.formatPrice(totals.shipping) : "Free") + "</dd></div>" +
          '<div class="total"><dt>Total</dt><dd id="cartTotal">' + Shopora.formatPrice(totals.total) + "</dd></div></dl>" +
        '<form class="coupon" id="couponForm"><input type="text" id="couponInput" placeholder="Coupon code" aria-label="Coupon code">' +
          '<button class="btn btn-outline btn-sm" type="submit">Apply</button></form>' +
        '<small class="coupon-msg" id="couponMsg">Try <strong>' + COUPON_CODE + "</strong> for 10% off.</small>" +
        '<button class="btn btn-primary btn-full btn-lg" id="checkoutBtn">Proceed to Checkout</button>' +
        '<p class="demo-note">Demo checkout: no payment is taken and no data leaves your browser.</p>' +
      "</aside></div>";
  }

  function checkout() {
    const lines = getLines();
    if (lines.length === 0) { return; }
    if (!Store.getUser()) {
      Shopora.toast("Please log in to place your order");
      setTimeout(function () { window.location.href = "login.html?next=cart"; }, 900);
      return;
    }
    const totals = calculate(lines);
    const orders = Store.getOrders();
    const order = {
      id: "SH" + (1001 + orders.length),
      date: new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }),
      items: lines.map(function (l) { return { name: l.product.name, qty: l.qty, price: l.product.price }; }),
      total: totals.total,
      email: Store.getUser().email
    };
    orders.unshift(order);
    Store.saveOrders(orders);
    Store.clearCart();
    couponApplied = false;
    Shopora.updateCounts();

    document.getElementById("cartContent").innerHTML =
      '<div class="empty-state success"><div class="success-icon">' + Shopora.icon("check") + "</div>" +
      "<h2>Thank you for your order!</h2><p>Order <strong>" + order.id + "</strong> for <strong>" + Shopora.formatPrice(order.total) +
      '</strong> has been placed (demo).</p><div class="btn-row"><a class="btn btn-primary" href="login.html#orders">View my orders</a>' +
      '<a class="btn btn-outline" href="products.html">Keep shopping</a></div></div>';
  }

  function bindEvents() {
    document.getElementById("cartContent").addEventListener("click", function (e) {
      const btn = e.target.closest("[data-cart]");
      if (!btn) { return; }
      const action = btn.dataset.cart;
      const id = Number(btn.dataset.id);
      const entry = Store.getCart().find(function (i) { return i.id === id; });

      if (action === "plus" && entry) { Store.setQty(id, entry.qty + 1); }
      if (action === "minus" && entry) { Store.setQty(id, entry.qty - 1); }   // qty 0 removes the item
      if (action === "remove") { Store.removeFromCart(id); Shopora.toast("Item removed from cart"); }
      if (action === "clear") { Store.clearCart(); Shopora.toast("Cart cleared"); }
      render();
    });

    document.getElementById("cartContent").addEventListener("click", function (e) {
      if (e.target.id === "checkoutBtn") { checkout(); }
    });

    document.getElementById("cartContent").addEventListener("submit", function (e) {
      if (e.target.id !== "couponForm") { return; }
      e.preventDefault();
      const code = document.getElementById("couponInput").value.trim().toUpperCase();
      if (code === COUPON_CODE) { couponApplied = true; render(); Shopora.toast("Coupon applied: 10% off"); }
      else {
        const msg = document.getElementById("couponMsg");
        msg.textContent = code ? "Invalid coupon code." : "Please enter a coupon code.";
        msg.className = "coupon-msg bad";
      }
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    bindEvents();
    render();
  });
})();
