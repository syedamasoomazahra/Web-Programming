/* =====================================================================
   SHOPORA - contact.js  (contact.html)
   Contact form validation. This is a front-end demonstration: the
   message is not sent to a server (a backend would be needed for that).
   ===================================================================== */

(function () {
  function setError(id, message) {
    const input = document.getElementById(id);
    document.getElementById(id + "Error").textContent = message;
    input.classList.toggle("invalid", Boolean(message));
    input.setAttribute("aria-invalid", Boolean(message));
    return !message;
  }

  function checkName() {
    const v = document.getElementById("contactName").value.trim();
    if (v.length < 3) { return setError("contactName", "Please enter your full name (min 3 characters)."); }
    return setError("contactName", "");
  }

  function checkEmail() {
    const v = document.getElementById("contactEmail").value.trim();
    if (!v) { return setError("contactEmail", "Email is required."); }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) { return setError("contactEmail", "Enter a valid email address."); }
    return setError("contactEmail", "");
  }

  function checkSubject() {
    return document.getElementById("contactSubject").value
      ? setError("contactSubject", "")
      : setError("contactSubject", "Please choose a subject.");
  }

  function checkMessage() {
    const v = document.getElementById("contactMessage").value.trim();
    if (v.length < 10) { return setError("contactMessage", "Message must be at least 10 characters."); }
    return setError("contactMessage", "");
  }

  document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("contactForm");
    const message = document.getElementById("contactMessage");
    const counter = document.getElementById("charCount");

    // live character counter
    message.addEventListener("input", function () { counter.textContent = message.value.length + " / 500"; });

    document.getElementById("contactName").addEventListener("blur", checkName);
    document.getElementById("contactEmail").addEventListener("blur", checkEmail);
    document.getElementById("contactSubject").addEventListener("change", checkSubject);
    message.addEventListener("blur", checkMessage);

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      const results = [checkName(), checkEmail(), checkSubject(), checkMessage()];
      if (results.indexOf(false) !== -1) { return; }

      form.reset();
      counter.textContent = "0 / 500";
      const ok = document.getElementById("contactSuccess");
      ok.hidden = false;
      Shopora.toast("Message received (demo)");
      setTimeout(function () { ok.hidden = true; }, 6000);
    });
  });
})();
