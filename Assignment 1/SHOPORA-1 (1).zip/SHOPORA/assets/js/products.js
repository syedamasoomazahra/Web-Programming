/* =====================================================================
   SHOPORA - products.js  (products.html)
   Product listing: search, category / brand / price / rating filters,
   sorting, and the mobile filter panel.
   ===================================================================== */

(function () {
  /* The state of every filter control. */
  const state = { search: "", category: "All", price: "all", brands: [], rating: 0, sort: "featured", tag: "" };

  const PRICE_RANGES = {
    all: [0, Infinity],
    under5: [0, 5000],
    "5to10": [5000, 10000],
    "10to20": [10000, 20000],
    over20: [20000, Infinity]
  };

  /* ---------- Build the sidebar controls ---------- */
  function buildSidebar() {
    const catBox = document.getElementById("filterCategories");
    catBox.innerHTML = ["All"].concat(CATEGORIES.map(function (c) { return c.name; })).map(function (name) {
      const count = name === "All" ? PRODUCTS.length : PRODUCTS.filter(function (p) { return p.category === name; }).length;
      return '<label class="check"><input type="radio" name="category" value="' + name + '"' + (name === "All" ? " checked" : "") + ">" +
             "<span>" + name + '</span><em>' + count + "</em></label>";
    }).join("");

    const brandBox = document.getElementById("filterBrands");
    brandBox.innerHTML = BRANDS.map(function (b) {
      return '<label class="check"><input type="checkbox" name="brand" value="' + b + '"><span>' + b + "</span></label>";
    }).join("");
  }

  /* ---------- Apply filters + sorting ---------- */
  function getResults() {
    const q = state.search.toLowerCase();
    const range = PRICE_RANGES[state.price];

    let list = PRODUCTS.filter(function (p) {
      const haystack = (p.name + " " + p.brand + " " + p.category + " " + p.description).toLowerCase();
      if (q && haystack.indexOf(q) === -1) { return false; }
      if (state.category !== "All" && p.category !== state.category) { return false; }
      if (p.price < range[0] || p.price >= range[1]) { return false; }
      if (state.brands.length && state.brands.indexOf(p.brand) === -1) { return false; }
      if (p.rating < state.rating) { return false; }
      if (state.tag && p.tags.indexOf(state.tag) === -1) { return false; }
      return true;
    });

    const sorters = {
      "price-asc":  function (a, b) { return a.price - b.price; },
      "price-desc": function (a, b) { return b.price - a.price; },
      "rating":     function (a, b) { return b.rating - a.rating; },
      "name":       function (a, b) { return a.name.localeCompare(b.name); },
      "popular":    function (a, b) { return b.reviews - a.reviews; }
    };
    if (sorters[state.sort]) { list = list.slice().sort(sorters[state.sort]); }
    return list;
  }

  /* ---------- Draw results ---------- */
  function render() {
    const list = getResults();
    Shopora.renderCards(list, "productGrid", "No products match your search or filters. Try clearing some filters.");

    document.getElementById("resultInfo").textContent =
      list.length + (list.length === 1 ? " product" : " products") +
      (state.category !== "All" ? " in " + state.category : "") +
      (state.search ? ' for "' + state.search + '"' : "");

    renderChips();
    document.getElementById("pageHeading").textContent = state.category !== "All" ? state.category : "All Products";
  }

  /* Active-filter chips (click one to remove that filter). */
  function renderChips() {
    const chips = [];
    if (state.search) { chips.push(["search", 'Search: "' + state.search + '"']); }
    if (state.category !== "All") { chips.push(["category", state.category]); }
    if (state.price !== "all") {
      chips.push(["price", document.querySelector('input[name="price"][value="' + state.price + '"]').parentElement.textContent.trim()]);
    }
    state.brands.forEach(function (b) { chips.push(["brand:" + b, b]); });
    if (state.rating) { chips.push(["rating", state.rating + "★ & up"]); }
    if (state.tag) { chips.push(["tag", state.tag === "offer" ? "Special offers" : state.tag]); }

    document.getElementById("activeChips").innerHTML = chips.map(function (c) {
      return '<button class="chip" data-chip="' + c[0] + '">' + Shopora.escape(c[1]) + " &times;</button>";
    }).join("");
  }

  /* ---------- Sync controls <-> state ---------- */
  function readControls() {
    state.category = document.querySelector('input[name="category"]:checked').value;
    state.price = document.querySelector('input[name="price"]:checked').value;
    state.rating = Number(document.querySelector('input[name="rating"]:checked').value);
    state.brands = Array.from(document.querySelectorAll('input[name="brand"]:checked')).map(function (i) { return i.value; });
    state.sort = document.getElementById("sortSelect").value;
    render();
  }

  function setControls() {
    document.querySelector('input[name="category"][value="' + state.category + '"]').checked = true;
    document.querySelector('input[name="price"][value="' + state.price + '"]').checked = true;
    document.querySelector('input[name="rating"][value="' + state.rating + '"]').checked = true;
    document.querySelectorAll('input[name="brand"]').forEach(function (i) { i.checked = state.brands.indexOf(i.value) !== -1; });
    document.getElementById("sortSelect").value = state.sort;
    document.getElementById("headerSearch").value = state.search;
  }

  function clearFilters() {
    state.search = ""; state.category = "All"; state.price = "all"; state.brands = []; state.rating = 0; state.tag = "";
    setControls();
    render();
  }

  /* ---------- Events ---------- */
  function bindEvents() {
    document.getElementById("filterPanel").addEventListener("change", readControls);
    document.getElementById("sortSelect").addEventListener("change", readControls);
    document.getElementById("clearFilters").addEventListener("click", clearFilters);
    document.addEventListener("click", function (e) {
      if (e.target.id === "clearFromEmpty") { clearFilters(); }
    });

    // live search while typing in the header search box
    const search = document.getElementById("headerSearch");
    search.addEventListener("input", function () { state.search = search.value.trim(); render(); });

    // remove one filter by clicking its chip
    document.getElementById("activeChips").addEventListener("click", function (e) {
      const chip = e.target.closest("[data-chip]");
      if (!chip) { return; }
      const key = chip.dataset.chip;
      if (key === "search") { state.search = ""; }
      else if (key === "category") { state.category = "All"; }
      else if (key === "price") { state.price = "all"; }
      else if (key === "rating") { state.rating = 0; }
      else if (key === "tag") { state.tag = ""; }
      else if (key.indexOf("brand:") === 0) { state.brands = state.brands.filter(function (b) { return b !== key.slice(6); }); }
      setControls();
      render();
    });

    // mobile: open / close the filter panel
    const sidebar = document.getElementById("sidebar");
    document.getElementById("filterToggle").addEventListener("click", function () { sidebar.classList.toggle("open"); });
    document.getElementById("filterClose").addEventListener("click", function () { sidebar.classList.remove("open"); });
  }

  /* ---------- Start ---------- */
  document.addEventListener("DOMContentLoaded", function () {
    buildSidebar();

    // read ?category= ?q= ?tag= from the URL (links from home page / header search)
    const cat = Shopora.getParam("category");
    if (cat && CATEGORIES.some(function (c) { return c.name === cat; })) { state.category = cat; }
    state.search = (Shopora.getParam("q") || "").trim();
    state.tag = Shopora.getParam("tag") || "";

    setControls();
    bindEvents();
    render();
  });
})();
