/* =====================================================================
   SHOPORA - wishlist.js  (wishlist.html)
   Displays saved products, lets the user remove them or move them to
   the cart. The heart button on each card is handled in app.js; this
   file re-draws the page when the wishlist changes.
   ===================================================================== */

(function () {
  function render() {
    const ids = Store.getWishlist();
    const list = ids.map(Shopora.getProduct).filter(Boolean);
    const bar = document.getElementById("wishActions");
    const count = document.getElementById("wishSummary");

    count.textContent = list.length ? list.length + (list.length === 1 ? " saved item" : " saved items") : "";
    bar.hidden = list.length === 0;

    if (list.length === 0) {
      document.getElementById("wishlistGrid").innerHTML =
        '<div class="empty-state"><h2>Your wishlist is empty</h2><p>Tap the heart on any product to save it here.</p>' +
        '<a class="btn btn-primary" href="products.html">Discover products</a></div>';
      return;
    }
    Shopora.renderCards(list, "wishlistGrid");
  }

  document.addEventListener("DOMContentLoaded", function () {
    render();

    // heart button on a card (handled in app.js) -> redraw so the card disappears
    document.addEventListener("wishlist:changed", render);

    document.getElementById("moveAllBtn").addEventListener("click", function () {
      const ids = Store.getWishlist();
      ids.forEach(function (id) { Store.addToCart(id, 1); });
      Shopora.updateCounts();
      Shopora.toast(ids.length + " item(s) moved to cart");
      setTimeout(function () { window.location.href = "cart.html"; }, 700);
    });

    document.getElementById("clearWishBtn").addEventListener("click", function () {
      Store.getWishlist().slice().forEach(Store.removeFromWishlist);
      Shopora.updateCounts();
      Shopora.toast("Wishlist cleared");
      render();
    });
  });
})();
