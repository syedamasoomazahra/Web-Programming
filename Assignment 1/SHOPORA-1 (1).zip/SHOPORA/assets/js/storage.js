/* =====================================================================
   SHOPORA - storage.js
   Reusable Local Storage helpers for cart, wishlist, user and orders.
   Everything is wrapped in try/catch so the site still works when
   storage is blocked (private mode etc.).
   ===================================================================== */

const Store = (function () {
  const KEYS = {
    cart: "shopora_cart",         // [{ id, qty }]
    wishlist: "shopora_wishlist", // [id, id, ...]
    user: "shopora_user",         // { name, email } (logged-in user)
    users: "shopora_users",       // registered demo users
    orders: "shopora_orders"      // placed demo orders
  };

  function read(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw === null ? fallback : JSON.parse(raw);
    } catch (e) {
      return fallback;
    }
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) { /* storage unavailable: ignore */ }
  }

  function remove(key) {
    try { localStorage.removeItem(key); } catch (e) { /* ignore */ }
  }

  /* ---------- Cart ---------- */
  function getCart() { return read(KEYS.cart, []); }
  function saveCart(cart) { write(KEYS.cart, cart); }

  function addToCart(id, qty) {
    const cart = getCart();
    const item = cart.find(function (i) { return i.id === id; });
    if (item) { item.qty = Math.min(item.qty + qty, 99); } else { cart.push({ id: id, qty: Math.min(qty, 99) }); }
    saveCart(cart);
  }

  function setQty(id, qty) {
    let cart = getCart();
    if (qty < 1) {
      cart = cart.filter(function (i) { return i.id !== id; });
    } else {
      cart.forEach(function (i) { if (i.id === id) { i.qty = Math.min(qty, 99); } });
    }
    saveCart(cart);
  }

  function removeFromCart(id) {
    saveCart(getCart().filter(function (i) { return i.id !== id; }));
  }

  function clearCart() { saveCart([]); }

  function cartCount() {
    return getCart().reduce(function (sum, i) { return sum + i.qty; }, 0);
  }

  /* ---------- Wishlist ---------- */
  function getWishlist() { return read(KEYS.wishlist, []); }
  function isWished(id) { return getWishlist().indexOf(id) !== -1; }

  /* Adds or removes an id. Returns true when the product is now in the wishlist. */
  function toggleWishlist(id) {
    let list = getWishlist();
    const exists = list.indexOf(id) !== -1;
    list = exists ? list.filter(function (x) { return x !== id; }) : list.concat(id);
    write(KEYS.wishlist, list);
    return !exists;
  }

  function removeFromWishlist(id) {
    write(KEYS.wishlist, getWishlist().filter(function (x) { return x !== id; }));
  }

  /* ---------- User (front-end demo only, no backend) ---------- */
  function getUser() { return read(KEYS.user, null); }
  function setUser(user) { write(KEYS.user, user); }
  function logout() { remove(KEYS.user); }
  function getUsers() { return read(KEYS.users, []); }
  function saveUsers(users) { write(KEYS.users, users); }

  /* ---------- Orders (demo) ---------- */
  function getOrders() { return read(KEYS.orders, []); }
  function saveOrders(orders) { write(KEYS.orders, orders); }

  return {
    getCart: getCart, addToCart: addToCart, setQty: setQty, removeFromCart: removeFromCart,
    clearCart: clearCart, cartCount: cartCount,
    getWishlist: getWishlist, isWished: isWished, toggleWishlist: toggleWishlist,
    removeFromWishlist: removeFromWishlist,
    getUser: getUser, setUser: setUser, logout: logout, getUsers: getUsers, saveUsers: saveUsers,
    getOrders: getOrders, saveOrders: saveOrders
  };
})();
