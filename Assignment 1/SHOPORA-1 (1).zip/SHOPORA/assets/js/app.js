/* =====================================================================
   SHOPORA - app.js
   Common code used on every page:
   - header / footer / navigation drawer (rendered once, shared)
   - toast messages, count badges, product card markup
   - add-to-cart and wishlist buttons (event delegation)
   - homepage: slideshow, category grid, product sections
   - small UI helpers (scroll reveal, back-to-top, newsletter demo)
   ===================================================================== */

const Shopora = {};

/* ---------------------------------------------------------------------
   1. Helpers
   --------------------------------------------------------------------- */

Shopora.formatPrice = function (amount) {
  return CURRENCY + amount.toLocaleString("en-US");
};

Shopora.getProduct = function (id) {
  return PRODUCTS.find(function (p) { return p.id === Number(id); });
};

/* Escape text before putting it into innerHTML. */
Shopora.escape = function (text) {
  const div = document.createElement("div");
  div.textContent = String(text);
  return div.innerHTML;
};

/* Pexels CDN address for a local image path like "assets/images/p01-headphones.jpg". */
Shopora.remoteUrl = function (localPath) {
  const name = String(localPath).split("/").pop().replace(/\.jpg$/i, "");
  const info = REMOTE_IMAGES[name];
  return info ? "https://images.pexels.com/photos/" + info[0] + "/pexels-photo-" + info[0] + ".jpeg?auto=compress&cs=tinysrgb&w=" + info[1] : "";
};

/* Use an image as a CSS background: local file first, Pexels CDN if the file is missing.
   The address is stored in the --bg-img variable (see style.css). */
Shopora.setBackground = function (el, localPath) {
  const test = new Image();
  test.onload = function () { el.style.setProperty("--bg-img", 'url("' + localPath + '")'); };
  test.onerror = function () {
    const remote = Shopora.remoteUrl(localPath);
    if (remote) { el.style.setProperty("--bg-img", 'url("' + remote + '")'); }
  };
  test.src = localPath;
};

/* Small inline SVG icon set (stroke icons). */
Shopora.icon = function (name) {
  const paths = {
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
    heart: '<path d="M12 20.5s-7.5-4.6-9.2-9.4C1.6 7.8 3.6 4.8 6.7 4.8c2 0 3.5 1.1 5.3 3 1.8-1.9 3.3-3 5.3-3 3.1 0 5.1 3 3.9 6.3-1.7 4.8-9.2 9.4-9.2 9.4z"/>',
    bag: '<path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8V6.5a3 3 0 016 0V8"/>',
    user: '<circle cx="12" cy="8" r="3.8"/><path d="M4.5 20c.8-3.6 3.8-5.5 7.5-5.5s6.7 1.9 7.5 5.5"/>',
    truck: '<path d="M3 6h11v10H3zM14 9h4l3 3v4h-7"/><circle cx="7.5" cy="17.5" r="1.7"/><circle cx="17" cy="17.5" r="1.7"/>',
    shield: '<path d="M12 3l7 3v5.5c0 4.5-3 7.8-7 9.5-4-1.7-7-5-7-9.5V6l7-3z"/><path d="M9 12l2.2 2.2L15.5 10"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7"/><path d="M20 5v6h-6"/>',
    star: '<path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 16.9l-5.2 2.8 1-5.9-4.3-4.1 5.9-.8L12 3.5z"/>',
    arrowRight: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    chevronLeft: '<path d="M15 5l-7 7 7 7"/>',
    chevronRight: '<path d="M9 5l7 7-7 7"/>',
    home: '<path d="M4 11l8-7 8 7v9H4z"/>',
    box: '<path d="M4 8l8-4 8 4v8l-8 4-8-4V8z"/><path d="M4 8l8 4 8-4M12 12v8"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M18.4 5.6l-1.8 1.8M7.4 16.6l-1.8 1.8"/>',
    logout: '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>',
    trash: '<path d="M5 7h14M9 7V5h6v2M7 7l1 13h8l1-13"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    mail: '<path d="M3.5 6h17v12h-17z"/><path d="M3.5 7l8.5 6 8.5-6"/>',
    phone: '<path d="M6.5 3.5l3 .5 1 4-2 1.5a11 11 0 005 5l1.5-2 4 1 .5 3c-1 2-2.5 2.5-4 2.5A15 15 0 013.5 7.5c0-1.5.5-3 3-4z"/>',
    pin: '<path d="M12 21s6.5-5.7 6.5-11a6.5 6.5 0 10-13 0C5.5 15.3 12 21 12 21z"/><circle cx="12" cy="10" r="2.3"/>'
  };
  return '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + (paths[name] || "") + "</svg>";
};

/* "Stars" shown as a CSS-clipped row; --rating is read by style.css */
Shopora.starsHTML = function (rating, reviews) {
  let html = '<span class="rating" title="' + rating.toFixed(1) + ' out of 5">' +
             '<span class="stars" style="--rating:' + rating + '" aria-hidden="true">★★★★★</span>' +
             '<span class="rating-num">' + rating.toFixed(1) + "</span>";
  if (reviews) { html += '<span class="rating-count">(' + reviews + ")</span>"; }
  return html + "</span>";
};

/* Toast message at the bottom of the screen */
Shopora.toastTimer = null;
Shopora.toast = function (message) {
  let el = document.getElementById("toast");
  if (!el) {
    el = document.createElement("div");
    el.id = "toast";
    el.className = "toast";
    el.setAttribute("role", "status");
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(Shopora.toastTimer);
  Shopora.toastTimer = setTimeout(function () { el.classList.remove("show"); }, 2300);
};

/* ---------------------------------------------------------------------
   2. Shared layout: header, drawer, footer
   --------------------------------------------------------------------- */

Shopora.logoHTML = function (light) {
  return '<a class="logo' + (light ? " logo-light" : "") + '" href="index.html" aria-label="SHOPORA home">' +
    '<svg class="logo-mark" viewBox="0 0 40 40" aria-hidden="true">' +
    '<circle cx="20" cy="20" r="18.5" fill="none" stroke="currentColor" stroke-width="1.4"/>' +
    '<path d="M25.5 13.2c-1.4-1.6-3.3-2.4-5.6-2.4-3.3 0-5.6 1.7-5.6 4.3 0 6.4 11.8 3.1 11.8 9.6 0 2.8-2.5 4.7-6.1 4.7-2.5 0-4.7-.9-6.2-2.7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>' +
    "</svg>" +
    '<span class="logo-word">SHOPORA</span></a>';
};

Shopora.renderHeader = function () {
  const holder = document.getElementById("site-header");
  if (!holder) { return; }
  const page = document.body.dataset.page || "";
  const user = Store.getUser();
  const link = function (href, label, key) {
    return '<a class="nav-link' + (page === key ? " active" : "") + '" href="' + href + '">' + label + "</a>";
  };

  holder.innerHTML =
    '<div class="topbar"><p>Free delivery on orders over ' + Shopora.formatPrice(15000) + ' &nbsp;·&nbsp; Easy 14-day returns</p></div>' +
    '<header class="site-header" id="siteHeader"><div class="container header-inner">' +
      '<button class="icon-btn menu-btn" id="menuBtn" aria-label="Open menu" aria-controls="drawer">' + Shopora.icon("menu") + "</button>" +
      Shopora.logoHTML(false) +
      '<nav class="main-nav" aria-label="Main navigation">' +
        link("index.html", "Home", "home") +
        link("products.html", "Products", "products") +
        link("index.html#categories", "Categories", "categories") +
        link("about.html", "About Us", "about") +
        link("contact.html", "Contact Us", "contact") +
      "</nav>" +
      '<form class="search-box" id="headerSearchForm" role="search">' +
        '<input type="search" id="headerSearch" placeholder="Search products…" autocomplete="off" aria-label="Search products">' +
        '<button type="submit" aria-label="Search">' + Shopora.icon("search") + "</button>" +
      "</form>" +
      '<div class="header-actions">' +
        '<a class="auth-link' + (page === "login" ? " active" : "") + '" href="login.html" id="authLink">' +
          Shopora.icon("user") + "<span>" + (user ? Shopora.escape(user.name.split(" ")[0]) : "Login / Signup") + "</span></a>" +
        '<a class="icon-btn" href="wishlist.html" aria-label="Wishlist">' + Shopora.icon("heart") + '<span class="badge" id="wishCount">0</span></a>' +
        '<a class="icon-btn" href="cart.html" aria-label="Shopping cart" id="cartIcon">' + Shopora.icon("bag") + '<span class="badge" id="cartCount">0</span></a>' +
      "</div>" +
    "</div></header>" +

    '<div class="overlay" id="overlay"></div>' +
    '<aside class="drawer" id="drawer" aria-label="Navigation drawer" aria-hidden="true">' +
      '<div class="drawer-head">' + Shopora.logoHTML(false) +
        '<button class="icon-btn" id="closeDrawer" aria-label="Close menu">' + Shopora.icon("close") + "</button></div>" +
      '<p class="drawer-hello" id="drawerHello"></p>' +
      '<ul class="drawer-list">' +
        '<li><a href="index.html">' + Shopora.icon("home") + "Home</a></li>" +
        '<li><a href="login.html#profile">' + Shopora.icon("user") + "My Profile</a></li>" +
        '<li><a href="login.html#orders">' + Shopora.icon("box") + "My Orders</a></li>" +
        '<li><a href="wishlist.html">' + Shopora.icon("heart") + "Wishlist</a></li>" +
        '<li><a href="login.html#settings">' + Shopora.icon("gear") + "Settings</a></li>" +
        '<li><button type="button" id="logoutBtn">' + Shopora.icon("logout") + "Logout</button></li>" +
      "</ul>" +
      '<div class="drawer-shop"><h4>Shop</h4>' +
        CATEGORIES.map(function (c) {
          return '<a href="products.html?category=' + encodeURIComponent(c.name) + '">' + c.name + "</a>";
        }).join("") +
      "</div>" +
    "</aside>";
};

Shopora.renderFooter = function () {
  const holder = document.getElementById("site-footer");
  if (!holder) { return; }
  holder.innerHTML =
    '<footer class="site-footer"><div class="container footer-grid">' +
      '<div class="footer-col footer-about">' + Shopora.logoHTML(true) +
        "<p>SHOPORA brings carefully chosen fashion, accessories and home essentials together in one calm, easy place to shop.</p>" +
        '<div class="social">' +
          '<a href="https://www.facebook.com/" target="_blank" rel="noopener" aria-label="Facebook"><svg viewBox="0 0 24 24"><path d="M14 8.5V7c0-.8.3-1.2 1.3-1.2H17V3h-2.6C11.7 3 10.5 4.6 10.5 6.8v1.7H8V12h2.5v9H14v-9h2.6l.4-3.5H14z"/></svg></a>' +
          '<a href="https://www.instagram.com/" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24"><path d="M7.5 3h9A4.5 4.5 0 0121 7.5v9a4.5 4.5 0 01-4.5 4.5h-9A4.5 4.5 0 013 16.5v-9A4.5 4.5 0 017.5 3zm0 1.8A2.7 2.7 0 004.8 7.5v9a2.7 2.7 0 002.7 2.7h9a2.7 2.7 0 002.7-2.7v-9a2.7 2.7 0 00-2.7-2.7h-9zM12 7.6a4.4 4.4 0 110 8.8 4.4 4.4 0 010-8.8zm0 1.8a2.6 2.6 0 100 5.2 2.6 2.6 0 000-5.2zm4.7-2.9a1 1 0 110 2 1 1 0 010-2z"/></svg></a>' +
          '<a href="https://x.com/" target="_blank" rel="noopener" aria-label="X (Twitter)"><svg viewBox="0 0 24 24"><path d="M17.8 3h3L14.2 10.5 22 21h-6.1l-4.8-6.3L5.6 21h-3l7.1-8L2.2 3h6.2l4.3 5.8L17.8 3zm-1.1 16.2h1.7L7.5 4.7H5.7l11 14.5z"/></svg></a>' +
          '<a href="https://www.pinterest.com/" target="_blank" rel="noopener" aria-label="Pinterest"><svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 00-3.3 17.3c-.1-.7-.1-1.800 0-2.600l1.100-4.600s-.3-.6-.3-1.400c0-1.300.8-2.300 1.700-2.300.8 0 1.200.6 1.200 1.300 0 .8-.5 2-.8 3.100-.2.900.5 1.700 1.400 1.700 1.700 0 3-1.800 3-4.400 0-2.300-1.600-3.900-4-3.900-2.700 0-4.300 2-4.300 4.100 0 .8.300 1.700.7 2.100.1.100.1.200.1.300l-.3 1.100c0 .2-.1.200-.3.100-1.200-.6-2-2.400-2-3.800 0-3.100 2.300-6 6.500-6 3.400 0 6 2.400 6 5.700 0 3.400-2.100 6.100-5.100 6.100-1 0-1.900-.5-2.200-1.100l-.6 2.300c-.2.800-.8 1.800-1.200 2.400A9 9 0 1012 3z"/></svg></a>' +
        "</div></div>" +
      '<div class="footer-col"><h4>Quick Links</h4><ul>' +
        '<li><a href="index.html">Home</a></li><li><a href="products.html">All Products</a></li>' +
        '<li><a href="wishlist.html">Wishlist</a></li><li><a href="cart.html">Shopping Cart</a></li>' +
        '<li><a href="login.html">Login / Signup</a></li></ul></div>' +
      '<div class="footer-col"><h4>Company</h4><ul>' +
        '<li><a href="about.html">About Us</a></li><li><a href="contact.html">Contact Us</a></li>' +
        '<li><a href="index.html#categories">Categories</a></li><li><a href="login.html#orders">My Orders</a></li></ul></div>' +
      '<div class="footer-col"><h4>Contact</h4><ul class="contact-list">' +
        "<li>" + Shopora.icon("pin") + "Gulberg Green, Islamabad, Pakistan</li>" +
        "<li>" + Shopora.icon("phone") + "+92 300 1234567</li>" +
        "<li>" + Shopora.icon("mail") + "support@shopora.com</li></ul>" +
        '<form class="newsletter" id="newsletterForm" novalidate><label class="sr-only" for="newsletterEmail">Email</label>' +
          '<input type="email" id="newsletterEmail" placeholder="Your email address">' +
          '<button type="submit" class="btn btn-sm btn-primary">Join</button></form>' +
        '<small class="newsletter-msg" id="newsletterMsg"></small></div>' +
    "</div>" +
    '<div class="footer-bottom"><div class="container"><p>© <span id="year"></span> SHOPORA. A university project, front-end demonstration only; no real orders or payments.</p></div></div></footer>' +
    '<button class="to-top" id="toTop" aria-label="Back to top">' + Shopora.icon("chevronRight") + "</button>";
  document.getElementById("year").textContent = new Date().getFullYear();
};

/* ---------------------------------------------------------------------
   3. Navigation drawer (open / close with animation)
   --------------------------------------------------------------------- */

Shopora.openDrawer = function () {
  document.getElementById("drawer").classList.add("open");
  document.getElementById("drawer").setAttribute("aria-hidden", "false");
  document.getElementById("overlay").classList.add("show");
  document.body.classList.add("no-scroll");
};

Shopora.closeDrawer = function () {
  const drawer = document.getElementById("drawer");
  if (!drawer) { return; }
  drawer.classList.remove("open");
  drawer.setAttribute("aria-hidden", "true");
  document.getElementById("overlay").classList.remove("show");
  document.body.classList.remove("no-scroll");
};

Shopora.updateDrawerHello = function () {
  const el = document.getElementById("drawerHello");
  const user = Store.getUser();
  if (el) { el.textContent = user ? "Signed in as " + user.name : "Welcome, guest"; }
  const logout = document.getElementById("logoutBtn");
  if (logout) { logout.parentElement.style.display = user ? "" : "none"; }
};

/* ---------------------------------------------------------------------
   4. Counts (cart + wishlist badges) and product cards
   --------------------------------------------------------------------- */

Shopora.updateCounts = function () {
  const cart = document.getElementById("cartCount");
  const wish = document.getElementById("wishCount");
  if (cart) { cart.textContent = Store.cartCount(); cart.classList.toggle("has-items", Store.cartCount() > 0); }
  if (wish) { wish.textContent = Store.getWishlist().length; wish.classList.toggle("has-items", Store.getWishlist().length > 0); }
};

Shopora.cardHTML = function (p) {
  const wished = Store.isWished(p.id);
  let badge = "";
  if (p.oldPrice) {
    badge = '<span class="tag tag-sale">-' + Math.round((1 - p.price / p.oldPrice) * 100) + "%</span>";
  } else if (p.tags.indexOf("new") !== -1) {
    badge = '<span class="tag tag-new">New</span>';
  }
  return '<article class="product-card" data-id="' + p.id + '">' +
    '<div class="card-media">' +
      '<a href="product.html?id=' + p.id + '" aria-label="View ' + Shopora.escape(p.name) + '">' +
        '<img src="' + p.image + '" alt="' + Shopora.escape(p.name) + '" loading="lazy" width="600" height="750" referrerpolicy="no-referrer"></a>' +
      badge +
      '<button class="wish-btn' + (wished ? " active" : "") + '" data-action="wish" data-id="' + p.id + '" aria-label="Toggle wishlist" aria-pressed="' + wished + '">' + Shopora.icon("heart") + "</button>" +
    "</div>" +
    '<div class="card-body">' +
      '<p class="card-cat">' + p.category + " · " + p.brand + "</p>" +
      '<h3 class="card-title"><a href="product.html?id=' + p.id + '">' + Shopora.escape(p.name) + "</a></h3>" +
      Shopora.starsHTML(p.rating, p.reviews) +
      '<p class="price"><span class="price-now">' + Shopora.formatPrice(p.price) + "</span>" +
        (p.oldPrice ? '<span class="price-old">' + Shopora.formatPrice(p.oldPrice) + "</span>" : "") + "</p>" +
      '<div class="card-actions">' +
        '<button class="btn btn-primary btn-sm" data-action="add-cart" data-id="' + p.id + '">Add to Cart</button>' +
        '<a class="btn btn-outline btn-sm" href="product.html?id=' + p.id + '">View Details</a>' +
      "</div></div></article>";
};

/* Fill a container with cards (or an empty-state message). */
Shopora.renderCards = function (list, containerId, emptyText) {
  const box = document.getElementById(containerId);
  if (!box) { return; }
  if (list.length === 0) {
    box.innerHTML = '<div class="empty-state"><p>' + (emptyText || "Nothing to show yet.") + "</p></div>";
    return;
  }
  box.innerHTML = list.map(Shopora.cardHTML).join("");
};

/* Add-to-cart and wishlist buttons work everywhere (event delegation). */
Shopora.bindCardActions = function () {
  document.addEventListener("click", function (event) {
    const btn = event.target.closest("[data-action]");
    if (!btn) { return; }
    const action = btn.dataset.action;
    const id = Number(btn.dataset.id);
    const product = Shopora.getProduct(id);
    if (!product) { return; }

    if (action === "add-cart") {
      Store.addToCart(id, 1);
      Shopora.updateCounts();
      Shopora.pulse(document.getElementById("cartIcon"));
      Shopora.toast(product.name + " added to cart");
    }
    if (action === "wish") {
      const added = Store.toggleWishlist(id);
      btn.classList.toggle("active", added);
      btn.setAttribute("aria-pressed", added);
      Shopora.updateCounts();
      Shopora.pulse(btn);
      Shopora.toast(added ? "Added to wishlist" : "Removed from wishlist");
      document.dispatchEvent(new CustomEvent("wishlist:changed", { detail: { id: id, added: added } }));
    }
  });
};

/* Short "pop" animation on an element */
Shopora.pulse = function (el) {
  if (!el) { return; }
  el.classList.remove("pop");
  void el.offsetWidth; // restart the animation
  el.classList.add("pop");
};

/* ---------------------------------------------------------------------
   5. Homepage: slideshow, categories, product sections
   --------------------------------------------------------------------- */

Shopora.initSlideshow = function () {
  const root = document.getElementById("slideshow");
  if (!root) { return; }
  const track = root.querySelector(".slides");
  const dotsBox = root.querySelector(".slide-dots");

  track.innerHTML = SLIDES.map(function (s, i) {
    return '<div class="slide' + (i === 0 ? " active" : "") + '" data-bg="' + s.image + '">' +
      '<div class="slide-content"><span class="eyebrow">' + s.eyebrow + "</span><h2>" + s.title + "</h2><p>" + s.text + "</p>" +
      '<a class="btn btn-light" href="' + s.link + '">' + s.cta + " " + Shopora.icon("arrowRight") + "</a></div></div>";
  }).join("");
  dotsBox.innerHTML = SLIDES.map(function (s, i) {
    return '<button class="dot' + (i === 0 ? " active" : "") + '" aria-label="Go to slide ' + (i + 1) + '" data-index="' + i + '"></button>';
  }).join("");

  track.querySelectorAll(".slide").forEach(function (el) { Shopora.setBackground(el, el.dataset.bg); });
  const slides = track.querySelectorAll(".slide");
  const dots = dotsBox.querySelectorAll(".dot");
  let current = 0;
  let timer = null;

  function show(index) {
    current = (index + slides.length) % slides.length;
    slides.forEach(function (s, i) { s.classList.toggle("active", i === current); });
    dots.forEach(function (d, i) { d.classList.toggle("active", i === current); });
  }
  function start() { stop(); timer = setInterval(function () { show(current + 1); }, 5500); }
  function stop() { clearInterval(timer); }

  root.querySelector(".slide-btn.next").addEventListener("click", function () { show(current + 1); start(); });
  root.querySelector(".slide-btn.prev").addEventListener("click", function () { show(current - 1); start(); });
  dots.forEach(function (d) {
    d.addEventListener("click", function () { show(Number(d.dataset.index)); start(); });
  });
  root.addEventListener("mouseenter", stop);
  root.addEventListener("mouseleave", start);

  // swipe on touch screens
  let startX = 0;
  root.addEventListener("touchstart", function (e) { startX = e.touches[0].clientX; stop(); }, { passive: true });
  root.addEventListener("touchend", function (e) {
    const diff = e.changedTouches[0].clientX - startX;
    if (Math.abs(diff) > 40) { show(current + (diff < 0 ? 1 : -1)); }
    start();
  });

  start();
};

Shopora.renderCategories = function () {
  const box = document.getElementById("categoryGrid");
  if (!box) { return; }
  box.innerHTML = CATEGORIES.map(function (c) {
    return '<a class="category-card" href="products.html?category=' + encodeURIComponent(c.name) + '">' +
      '<img src="' + c.image + '" alt="' + c.name + '" loading="lazy">' +
      '<div class="category-info"><h3>' + c.name + "</h3><p>" + c.text + "</p></div></a>";
  }).join("");
};

Shopora.renderHomeSections = function () {
  const pick = function (tag, n) {
    return PRODUCTS.filter(function (p) { return p.tags.indexOf(tag) !== -1; }).slice(0, n);
  };
  Shopora.renderCards(pick("featured", 4), "featuredGrid");
  Shopora.renderCards(pick("new", 4), "newGrid");
  Shopora.renderCards(pick("best", 4), "bestGrid");
  Shopora.renderCards(pick("offer", 4), "offerGrid");
};

/* ---------------------------------------------------------------------
   6. Small UI features
   --------------------------------------------------------------------- */

/* Header search: on other pages it opens products.html?q=...  */
Shopora.initHeaderSearch = function () {
  const form = document.getElementById("headerSearchForm");
  if (!form) { return; }
  form.addEventListener("submit", function (event) {
    // On the products page products.js handles the search itself.
    if (document.body.dataset.page === "products") { event.preventDefault(); return; }
    event.preventDefault();
    const q = document.getElementById("headerSearch").value.trim();
    window.location.href = "products.html" + (q ? "?q=" + encodeURIComponent(q) : "");
  });
};

Shopora.initDrawerEvents = function () {
  document.getElementById("menuBtn").addEventListener("click", Shopora.openDrawer);
  document.getElementById("closeDrawer").addEventListener("click", Shopora.closeDrawer);
  document.getElementById("overlay").addEventListener("click", Shopora.closeDrawer);
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") { Shopora.closeDrawer(); } });
  document.querySelectorAll("#drawer a").forEach(function (a) { a.addEventListener("click", Shopora.closeDrawer); });
  document.getElementById("logoutBtn").addEventListener("click", function () {
    Store.logout();
    Shopora.closeDrawer();
    Shopora.toast("You have been logged out");
    setTimeout(function () { window.location.href = "login.html"; }, 600);
  });
};

/* Sticky header shadow + back-to-top button */
Shopora.initScrollEffects = function () {
  const header = document.getElementById("siteHeader");
  const toTop = document.getElementById("toTop");
  function onScroll() {
    const y = window.scrollY;
    if (header) { header.classList.toggle("scrolled", y > 10); }
    if (toTop) { toTop.classList.toggle("show", y > 500); }
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
  if (toTop) { toTop.addEventListener("click", function () { window.scrollTo({ top: 0, behavior: "smooth" }); }); }
};

/* Fade sections in when they scroll into view */
Shopora.initReveal = function () {
  const items = document.querySelectorAll(".reveal");
  if (!("IntersectionObserver" in window)) { items.forEach(function (i) { i.classList.add("visible"); }); return; }
  const observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) { entry.target.classList.add("visible"); observer.unobserve(entry.target); }
    });
  }, { threshold: 0.12 });
  items.forEach(function (i) { observer.observe(i); });
};

/* Footer newsletter (front-end demo: nothing is sent anywhere) */
Shopora.initNewsletter = function () {
  const form = document.getElementById("newsletterForm");
  if (!form) { return; }
  form.addEventListener("submit", function (event) {
    event.preventDefault();
    const input = document.getElementById("newsletterEmail");
    const msg = document.getElementById("newsletterMsg");
    const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value.trim());
    msg.textContent = ok ? "Thank you for subscribing! (demo)" : "Please enter a valid email address.";
    msg.className = "newsletter-msg " + (ok ? "ok" : "bad");
    if (ok) { input.value = ""; }
  });
};

/* Lets other pages' scripts reuse the same query-string reader. */
Shopora.getParam = function (name) {
  return new URLSearchParams(window.location.search).get(name);
};

/* Hide any broken image gracefully: shows a neutral tile with the alt text. */
Shopora.initImageFallback = function () {
  document.addEventListener("error", function (event) {
    const img = event.target;
    if (img.tagName !== "IMG") { return; }

    // 1st failure: the local file is missing -> try the same photo from the Pexels CDN
    if (!img.dataset.remoteTried) {
      img.dataset.remoteTried = "1";
      const remote = Shopora.remoteUrl(img.getAttribute("src") || "");
      if (remote) { img.referrerPolicy = "no-referrer"; img.src = remote; return; }
    }
    // 2nd failure (offline): show a neutral tile with the product name
    if (img.dataset.failed) { return; }
    img.dataset.failed = "1";
    img.classList.add("img-missing");
    img.src = "data:image/svg+xml;utf8," + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="750"><rect width="100%" height="100%" fill="#ebe3d2"/>' +
      '<text x="50%" y="50%" fill="#8a8575" font-family="Georgia,serif" font-size="26" text-anchor="middle">' +
      (img.alt || "SHOPORA").replace(/[<&>]/g, "") + "</text></svg>");
  }, true);
};

/* ---------------------------------------------------------------------
   7. Start-up (runs on every page)
   --------------------------------------------------------------------- */

document.addEventListener("DOMContentLoaded", function () {
  Shopora.initImageFallback();
  Shopora.renderHeader();
  Shopora.renderFooter();
  Shopora.initDrawerEvents();
  Shopora.initHeaderSearch();
  Shopora.bindCardActions();
  Shopora.updateCounts();
  Shopora.updateDrawerHello();
  Shopora.initNewsletter();
  Shopora.initScrollEffects();

  if (document.body.dataset.page === "home") {
    Shopora.initSlideshow();
    Shopora.renderCategories();
    Shopora.renderHomeSections();
  }
  if (document.body.dataset.page === "about") { Shopora.renderCategories(); }
  document.querySelectorAll("[data-bg]").forEach(function (el) { if (!el.classList.contains("slide")) { Shopora.setBackground(el, el.dataset.bg); } });
  // static icon placeholders: <span data-icon="truck"></span>
  document.querySelectorAll("[data-icon]").forEach(function (el) { el.innerHTML = Shopora.icon(el.dataset.icon); });
  Shopora.initReveal();
});
