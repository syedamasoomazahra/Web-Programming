SHOPORA - Online Shopping Website (HTML, CSS, JavaScript)
=========================================================
Riphah International University - Software Engineering
Assignment 2: Design and Development of an Online Shopping Website

STEP 1 - PRODUCT PHOTOS
-----------------------
All photographs are real stock photos from Pexels (free licence).
* With internet: they appear automatically. If a file is missing from
  assets/images/, the site loads the same photo from the Pexels website.
* For offline use (and for submission), save them into assets/images/ once:
    - Windows:  double-click  DOWNLOAD-IMAGES.bat
    - Any OS:   python download-images.py
  The script prints "ok" for each photo; assets/images/ then holds 39 .jpg
  files and the site no longer needs the internet.
  If a Pexels id ever stops working, change it in download-images.py AND in
  REMOTE_IMAGES at the top of assets/js/data.js.

STEP 2 - RUN
------------
Open this folder in Visual Studio Code, right-click index.html and choose
"Open with Live Server". (Opening index.html by double-click also works.)

PAGES
-----
index.html      Home: slideshow, categories, featured / new / best sellers / offers
products.html   Product list: search, category/brand/price/rating filters, sorting
product.html    Product details (product.html?id=3): quantity, add to cart, wishlist
cart.html       Cart: quantity +/-, remove, automatic totals, coupon, demo checkout
wishlist.html   Wishlist: add/remove, move all to cart
login.html      Login / Signup validation; after login: My Profile, My Orders, Settings
about.html      About SHOPORA
contact.html    Contact form with validation

JAVASCRIPT (assets/js/)
-----------------------
data.js             Product, category and slide data (edit products here)
storage.js          Local Storage helpers for cart, wishlist, user, orders
app.js              Header/footer/drawer, slideshow, product cards, toasts, shared code
products.js         Listing, search, filters, sorting
product-details.js  Product page
cart.js             Cart page and totals
wishlist.js         Wishlist page
auth.js             Login/signup validation and account area
contact.js          Contact form validation
Script order on every page: data.js, storage.js, app.js, then the page file.

DEMO COUPON:  SHOPORA10  (10% off in the cart)

FRONT-END DEMONSTRATIONS (no backend)
-------------------------------------
Login/Signup, checkout/orders, the contact form and the newsletter box run only
in the browser. Accounts, orders, cart and wishlist are kept in Local Storage.
No emails are sent, no payment is taken, and passwords are not secure (a real
shop needs a server and a database).

ASSIGNMENT CHECKLIST
--------------------
Navigation bar, slideshow (3 slides, auto + next/prev + dots), sidebar filters,
navigation drawer, home sections, 7 categories (the 5 required + Handbags and
Jewelry), product cards, details page, cart, footer, search, filtering, quantity
management, wishlist, form validation, dynamic updates, Local Storage.
Hover effects: image zoom, card lift + shadow, nav underline, button colour,
category zoom/overlay, wishlist heart. Animations: fade-in welcome banner,
slideshow transitions, bouncing trust icons, sliding drawer, pop on add-to-cart.
CSS: Flexbox, Grid, transitions, transform, keyframes, box-shadow, border-radius,
linear-gradient, position (relative/absolute/fixed/sticky), media queries, z-index.

PHOTO CREDITS
-------------
All photographs are from Pexels (https://www.pexels.com), used under the Pexels licence.
